#import <UIKit/UIKit.h>

// This class represents the G+ icon that shows
// up in the UIActivityViewController share sheet.
@interface ShareActivity : UIActivity

@end
