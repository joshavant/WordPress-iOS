#import "Activity.h"

@interface CreateActivity : Activity

@end
