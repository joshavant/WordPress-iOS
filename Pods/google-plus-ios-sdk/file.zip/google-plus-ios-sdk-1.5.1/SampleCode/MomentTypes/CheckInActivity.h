#import "Activity.h"

@interface CheckInActivity : Activity

@end
