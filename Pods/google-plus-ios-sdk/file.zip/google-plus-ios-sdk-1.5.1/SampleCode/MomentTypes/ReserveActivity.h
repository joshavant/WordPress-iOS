#import "Activity.h"

@interface ReserveActivity : Activity

@property(copy, nonatomic) NSString *startDate;
@property(copy, nonatomic) NSNumber *attendeeCount;

@end
